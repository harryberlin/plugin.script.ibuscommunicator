# -*- coding: utf-8 -*-

__author__ = 'harryberlin'

from resources.lib import service

if __name__ == '__main__':
    service.main()
