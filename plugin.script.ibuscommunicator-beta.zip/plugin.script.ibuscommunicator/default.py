#!/usr/bin/env python
# -*- coding: utf-8 -*-

from __future__ import unicode_literals
__author__ = u'harryberlin'
import sys
__all__ = [u'PY2', u'py2_encode', u'py2_decode']
PY2 = sys.version_info[0] == 2
import os
import platform
from resources.lib.kodi_actions import KODI_ACTIONS
if PY2:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from xbmc import translatePath as xbmc_translate_path
else:
    import xbmc
    import xbmcgui
    import xbmcaddon
    import xbmcvfs
    from xbmcvfs import translatePath as xbmc_translate_path
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo(u'id')
ADDON_NAME = ADDON.getAddonInfo(u'name')
ADDON_PATH = ADDON.getAddonInfo(u'path')
ADDON_USER_PATH = os.path.join(xbmc.translatePath(u'special://userdata'), u'addon_data', ADDON_ID)
ADDON_PDC_BG_PATH = os.path.join(ADDON_PATH, u'resources', u'skins', u'Default', u'media', u'pdc', u'bgs', u'default.png')
ADDON_URL = u'https://github.com/harryberlin/plugin.script.ibuscommunicator/raw/master/plugin.script.ibuscommunicator-beta.zip'
ICON = os.path.join(ADDON_PATH, u'icon.png')
PLATFORM = platform.system()
PLATFORM_OSMC = True
PLATFORM_LIBREELEC = False
PLATFORM_WINDOWS = False
PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, u'boot')
PLATFORM_HOME_DIR = os.path.join(os.path.sep, u'home', u'osmc')
PLATFORM_SUDO = u'sudo '
PLATFORM_KODI_LOGFILE = os.path.join(xbmc_translate_path(u'special://logpath'), u'kodi.log')
PLATFORM_KODI_OLDLOGFILE = os.path.join(xbmc_translate_path(u'special://logpath'), u'kodi.old.log')
PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(os.path.sep, u'boot', u'ibuscommunicator')
ADDON_INFO_LOGFILE = os.path.join(xbmc.translatePath(u'special://userdata'), u'addon_data', ADDON_ID, u'logfiles', u'info.log')
ADDON_IBUS_LOGFILE = os.path.join(xbmc.translatePath(u'special://userdata'), u'addon_data', ADDON_ID, u'logfiles', u'data.log')
PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, u'root')
PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, u'ibus.txt')
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CLOSE_DIALOG = 51
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110
if PY2:
    XBMC_LOG_LEVEL = xbmc.LOGNOTICE
else:
    XBMC_LOG_LEVEL = xbmc.LOGINFO

def log(string, lvl = 0):
    return xbmc.log(u'IBUSCOMMUNICATOR: %s' % string, XBMC_LOG_LEVEL)


def note(heading, message = None, time = 5000):
    import xbmcgui
    if PY2:
        pass
    else:
        try:
            heading = heading.decode(u'utf-8')
        except:
            pass

        if message:
            try:
                message = message.decode(u'utf-8')
            except:
                pass

    xbmcgui.Dialog().notification(heading=u'%s' % heading, message=u'%s' % message if message else u'', icon=ICON, time=time)
    log(u'NOTIFICATION: "%s%s"' % (heading, u' - %s' % message if message else u''))


def dialog_ok(label1, label2 = u'', label3 = u''):
    import xbmcgui
    if PY2:
        xbmcgui.Dialog().ok(ADDON_NAME, label1, label2, label3)
    else:
        xbmcgui.Dialog().ok(ADDON_NAME, u'%s%s%s' % (label1, u'\n%s' % label2 if label2 else u'', u'\n%s' % label3 if label3 else u''))


def get_addon_setting(id):
    setting = ADDON.getSetting(id)
    if setting.upper() == u'TRUE':
        return True
    if setting.upper() == u'FALSE':
        return False
    return u'%s' % setting


def set_addon_setting(id, value):
    if type(value) == u'bool':
        ADDON.setSetting(id, u'true' if value else u'false')
    else:
        ADDON.setSetting(id, u'%s' % value)


def get_property(property, id = 10000):
    import xbmcgui
    return xbmcgui.Window(id).getProperty(property)


def set_property(property, value, id = 10000):
    import xbmcgui
    xbmcgui.Window(id).setProperty(property, value)


def _pbhook(numblocks, blocksize, filesize, url = None, dp = None):
    if dp.iscanceled():
        raise Exception(u'dialog canceled')
    try:
        percent = min(numblocks * blocksize * 100 / filesize, 100)
        current_size = u'%.*f' % (2, numblocks * blocksize / 1024.0 / 1024.0)
        total_size = u'%.*f' % (2, filesize / 1024.0 / 1024.0)
        teststr = u'%s / %s MB / %s%%' % (current_size, total_size, percent)
        if PY2:
            dp.update(int(10 + percent * 0.4), u'Downloading...', teststr, u'%s%%' % int(10 + percent * 0.4))
        else:
            message = u'%s%s%s' % (u'Downloading...', teststr, u'%s%%' % int(10 + percent * 0.4))
            dp.update(int(10 + percent * 0.4), message)
    except:
        pass


def is_internet_available():
    if PY2:
        from urllib2 import urlopen
    else:
        from urllib.request import urlopen
    try:
        urlopen(ADDON_URL, timeout=5)
        return True
    except:
        return False


def copy_log_fileOLD(show_dialog = False):
    global PLATFORM_KODI_LOGFILE
    global PIBUS_LOGFILE
    global PLATFORM_EXPORT_LOGFILE_PATH
    import zipfile
    from datetime import datetime
    log(u'LOGFILE: COPY LOG FILE TO "/boot/ibuscommunicator"')
    if not os.path.exists(PLATFORM_EXPORT_LOGFILE_PATH):
        os.popen(u'sudo -s mkdir %s' % PLATFORM_EXPORT_LOGFILE_PATH)
    log(u'LOGFILE: Create Zip File')
    filename = datetime.now().strftime(u'%Y%m%d_%H%M%S_ibuscommunicator.zip')
    dest_logfile = os.path.join(PLATFORM_EXPORT_LOGFILE_PATH, filename)
    zip = zipfile.ZipFile(os.path.join(ADDON_USER_PATH, filename), u'w', zipfile.ZIP_DEFLATED)
    zip.write(PLATFORM_KODI_LOGFILE, os.path.split(PLATFORM_KODI_LOGFILE)[1])
    if not get_addon_setting(u'log_to_kodi'):
        zip.write(ADDON_INFO_LOGFILE, os.path.split(ADDON_INFO_LOGFILE)[1])
        zip.write(ADDON_IBUS_LOGFILE, os.path.split(ADDON_IBUS_LOGFILE)[1])
    if get_addon_setting(u'pibus'):
        os.popen(u'sudo chown -R osmc:osmc "%s"' % os.path.join(u'root'))
        os.popen(u'sudo chown -R osmc:osmc "%s"' % PIBUS_LOGFILE)
        zip.write(PIBUS_LOGFILE, os.path.split(PIBUS_LOGFILE)[1])
    zip.close()
    log(u'LOGFILE: Move Zip File')
    os.popen(u'sudo -s mv %s %s' % (os.path.join(ADDON_USER_PATH, filename), dest_logfile))
    if show_dialog:
        dialog_ok(u'LOGFILE: <%s>' % filename, u'created on:', PLATFORM_EXPORT_LOGFILE_PATH)


def copy_log_file(show_dialog = False):
    global PIBUS_LOGFILE_PATH
    global PLATFORM_WINDOWS
    import zipfile
    from datetime import datetime
    if not xbmcvfs.exists(PLATFORM_EXPORT_LOGFILE_PATH):
        call(u'mkdir %s' % PLATFORM_EXPORT_LOGFILE_PATH)
    log(u'LOGFILE: COPY LOG FILE TO "%s"' % PLATFORM_EXPORT_LOGFILE_PATH)
    if not xbmcvfs.exists(PLATFORM_EXPORT_LOGFILE_PATH):
        call(u'mkdir %s' % PLATFORM_EXPORT_LOGFILE_PATH)
    log(u'LOGFILE: Create Zip File')
    filename = datetime.now().strftime(u'%Y%m%d_%H%M%S_ibuscommunicator.zip')
    dest_logfile = os.path.join(PLATFORM_EXPORT_LOGFILE_PATH, filename)
    zip = zipfile.ZipFile(os.path.join(ADDON_USER_PATH, filename), u'w', zipfile.ZIP_DEFLATED)
    try:
        zip.write(PLATFORM_KODI_LOGFILE, os.path.split(PLATFORM_KODI_LOGFILE)[1])
        zip.write(PLATFORM_KODI_OLDLOGFILE, os.path.split(PLATFORM_KODI_OLDLOGFILE)[1])
        if not get_addon_setting(u'log_to_kodi'):
            zip.write(ADDON_INFO_LOGFILE, os.path.split(ADDON_INFO_LOGFILE)[1])
            zip.write(ADDON_IBUS_LOGFILE, os.path.split(ADDON_IBUS_LOGFILE)[1])
        if get_addon_setting(u'pibus'):
            if is_osmc():
                call(u'chown -R osmc:osmc "%s"' % PIBUS_LOGFILE_PATH)
                call(u'chown -R osmc:osmc "%s"' % PIBUS_LOGFILE)
            else:
                call(u'chown -R root:root "%s"' % PIBUS_LOGFILE_PATH)
                call(u'chown -R root:root "%s"' % PIBUS_LOGFILE)
            zip.write(PIBUS_LOGFILE, os.path.split(PIBUS_LOGFILE)[1])
        zip.close()
    except ValueError:
        log(u'LOGFILE: Can not create Zip File')
        zip.close()
        return

    if not PLATFORM_WINDOWS:
        log(u'LOGFILE: Move Zip File')
        call(u'mv %s %s' % (os.path.join(ADDON_USER_PATH, filename), dest_logfile))
    if show_dialog:
        dialog_ok(u'LOGFILE: <%s>' % filename, u'created on:', PLATFORM_EXPORT_LOGFILE_PATH)


def copy_extra_addon_files():
    import xbmcgui
    if not xbmcgui.Dialog().yesno(u'IBusCommunicator', u'Are your sure to copy / replace skin files?', u'', u'[COLOR FFFF0000]NO BACKUP FUNCTION INCLUDED[/COLOR]'):
        return
    if xbmc.getSkinDir() != u'skin.confluence-vertical':
        dialog_ok(u'Current skin in not "skin.confluence-vertical"')
        return
    addon_path = os.path.join(ADDON_PATH, u'resources', u'replace_skin_files', u'*.*')
    skin_path = os.path.join(xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo(u'path'), u'720p')
    os.popen(u'sudo -s cp %s %s' % (addon_path, skin_path))
    if not xbmcgui.Dialog().yesno(u'IBusCommunicator', u'Extra addon skin files were', u'copied / replaced.', yeslabel=u'Restart Kodi', nolabel=u'Reload Skin'):
        xbmc.executebuiltin(u'ReloadSkin()')
    else:
        os.popen(u'sudo systemctl restart mediacenter')


def _send_command(message):
    import time
    import socket
    clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clientsocket.settimeout(0.1)
    port = int(get_addon_setting(u'tcp_port'))
    try:
        clientsocket.connect((u'localhost', 8089))
    except socket.timeout:
        log(u'NO TCP SOCKET')
        return False

    log(u'# TCP %s: SEND >%s<' % (port, message.upper()))
    if PY2:
        clientsocket.send(message)
    else:
        clientsocket.send(bytearray(message))
    time.sleep(0.2)
    answer = clientsocket.recv(50).replace(str_to_bstr(u'\n'), str_to_bstr(u''))
    time.sleep(0.2)
    clientsocket.shutdown(True)
    log(u'# TCP Answer: %s' % answer)
    if answer == str_to_bstr(u'OK'):
        return True
    else:
        return False


def dialog_progressbar_timeout(dp, line_1, line_2, line_3, timeout = 3000):
    for _ in range(100, 0, -1):
        if dp.iscanceled():
            break
        if PY2:
            dp.update(_, line_1, line_2, line_3)
        else:
            dp.update(_, u'%s\n%s\n%s' % (line_1, line_2, line_3))
        xbmc.sleep(int(timeout / 100))


def update(owner, repo, branch = u'master'):
    import json
    if PY2:
        from urllib2 import urlopen
        from urllib import urlretrieve
    else:
        from urllib.request import urlopen
        from urllib.request import urlretrieve
    import zipfile
    dp = xbmcgui.DialogProgress()
    dp.create(u'Updating %s-Beta' % ADDON_NAME, u' ')
    if PY2:
        dp.update(1, u'Check Connection...', u' ', u'1%')
    else:
        dp.update(1, u'Check Connection...\n \n1%')
    try:
        if not is_internet_available():
            raise Exception(u'No Internet connection')
        if PY2:
            dp.update(5, u'Check for new Version on github...', u' ', u'5%')
        else:
            dp.update(5, u'Check for new Version on github...\n \n5%')
        try:
            url = u'https://api.github.com/repos/%s/%s/git/refs/heads/%s' % (owner, repo, branch)
            res = json.loads(urlopen(url).read())
            log(res)
            sha_url = res[u'object'][u'url']
            res = json.loads(urlopen(sha_url).read())
            commit_date = res[u'committer'][u'date']
            try:
                commit_message = res[u'message']
            except:
                commit_message = u'---------'

            sha = res[u'sha']
        except:
            raise Exception(u'Try again later')

        log(sha)
        try:
            import resources.lib.test
        except ImportError:
            if ADDON.getSettingString(u'github_sha') == sha:
                raise Exception(u'No Update required')

        if PY2:
            dp.update(10, u'Downloading...', u' ', u'10%')
        else:
            dp.update(10, u'Downloading...\n \n10%')
        target_path = os.path.join(ADDON_USER_PATH, u'plugin.script.ibuscommunicator-beta.zip')
        urlretrieve(ADDON_URL, target_path, lambda nb, bs, fs, url = url: _pbhook(nb, bs, fs, url, dp))
        if PY2:
            dp.update(50, u'Check Zipfile...', u' ', u'50%')
        else:
            dp.update(50, u'Check Zipfile...\n \n50%')
        the_zip_file = zipfile.ZipFile(target_path, u'r')
        ret = the_zip_file.testzip()
        if ret is not None:
            raise Exception(u'Zipfile is bad')
        if PY2:
            dp.update(50, u'Checked Zipfile...', u' ', u'50%')
        else:
            dp.update(50, u'Checked Zipfile...\n \n50%')
        zip_count = 0
        zip_max_count = len(the_zip_file.infolist())
        os.remove(ADDON_PATH + u'/resources/lib/pibus')
        for zipinfo in the_zip_file.infolist():
            zip_count += 1
            if zipinfo.filename.startswith(u'plugin.script.ibuscommunicator'):
                zipinfo.filename = zipinfo.filename.replace(u'plugin.script.ibuscommunicator', u'')
                if PY2:
                    dp.update(int(50 + int(float(zip_count) / float(zip_max_count) * 100) * 0.5), u'Extracting... %s' % os.path.split(zipinfo.filename)[1], u'%s / %s / %s%%' % (zip_count, zip_max_count, int(float(zip_count) / float(zip_max_count) * 100)), u'%s%%' % int(50 + int(float(zip_count) / float(zip_max_count) * 100) * 0.5))
                else:
                    dp.update(int(50 + int(float(zip_count) / float(zip_max_count) * 100) * 0.5), u'Extracting... %s\n%s / %s / %s%%\n%s%%' % (os.path.split(zipinfo.filename)[1],
                     zip_count,
                     zip_max_count,
                     int(float(zip_count) / float(zip_max_count) * 100),
                     int(50 + int(float(zip_count) / float(zip_max_count) * 100) * 0.5)))
                try:
                    import resources.lib.test
                    the_zip_file.extract(zipinfo, os.path.join(ADDON_PATH, u'test'))
                except ImportError:
                    the_zip_file.extract(zipinfo, ADDON_PATH)

        the_zip_file.close()
        set_addon_setting(u'github_sha', u'%s' % sha)
        xbmc.sleep(400)
        commit_str_date = u'%s' % commit_date.replace(u'T', u' ').replace(u'Z', u' ')
        dialog_progressbar_timeout(dp, u'Update done. REBOOT REQUIRED', u'Release: %s' % commit_str_date, u'%s' % commit_message, 7000)
        xbmc.executebuiltin(u'XBMC.UpdateLocalAddons()')
    except Exception as e:
        if PY2:
            dialog_progressbar_timeout(dp, e.message, u' ', u' ', 7000)
        else:
            dialog_progressbar_timeout(dp, e.args, u' ', u' ', 7000)
    finally:
        dp.close()


def open_obcgui():
    if not _send_command(str_to_bstr(u'obc;opengui')):
        note(u'Error by opening OBC GUI')


def text_to_ike(text, gong = 'False'):
    if not _send_command(str_to_bstr(u'text_to_ike;%s;%s' % (text, gong))):
        note(u'Error by sending TEXT TO IKE')


def set_time():
    if not _send_command(str_to_bstr(u'set_time')):
        note(u'Error by setting IKE Time')


def set_date():
    if not _send_command(str_to_bstr(u'set_date')):
        note(u'Error by setting IKE Date')


def get_lcm_oiltemp():
    if not _send_command(str_to_bstr(u'get_lcm_oiltemp')):
        note(u'Error by getting LCM Oiltemp')


def mirrors_fold():
    if not _send_command(str_to_bstr(u'mirrors_fold')):
        note(u'Error by folding Mirrors')


def mirrors_unfold():
    if not _send_command(str_to_bstr(u'mirrors_unfold')):
        note(u'Error by unfolding Mirrors')


def toggle_drl_light():
    if get_addon_setting(u'drl_light'):
        set_addon_setting(u'drl_light', False)
    else:
        set_addon_setting(u'drl_light', True)


def stg_coding():

    def code_us_sidemark():
        if not _send_command(str_to_bstr(u'code_us_sidemark')):
            note(u'Error by Request LCM Coding Data')

    def code_pwm_park():
        if not _send_command(str_to_bstr(u'code_pwm_park')):
            note(u'Error by Request LCM Coding Data')

    import xbmcgui
    if not xbmcgui.Dialog().yesno(u'CODING FUNCTIONS', u'Use this Function at your own risk!', u"Don't continue, if you're unsure", u'You know what you do? Are you sure?', u'Cancel', u"I'm sure"):
        return
    codings = [u'LCM-Coding: US SIDEMARK', u'LCM-Coding: (LCM.C20=>) PWM PARK LIGHTS FRONT']
    ret = xbmcgui.Dialog().select(u'CODING FUNCTIONS', codings)
    if ret == 0:
        code_us_sidemark()
    elif ret == 1:
        code_pwm_park()


def open_settings():
    import xbmcgui
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC(u'{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()


def connect_ibus():
    pass


def disconnect_ibus():
    pass


def bm_set_button_event(button_event):
    import xbmcgui
    log(u'Set Event for BM Button: %s' % button_event)
    favmusicpath = u'Favorite Music Path'
    favvideopath = u'Favorite Video Path'
    custom = u'-- CUSTOM --'
    reset = u'---- RESET ---'
    kodi_actions = sorted(KODI_ACTIONS.keys())
    kodi_actions.extend([favmusicpath,
     favvideopath,
     custom,
     reset])
    selected = xbmcgui.Dialog().select(u'Choose Kodi Function', kodi_actions)
    if selected != -1:
        if kodi_actions[selected] == reset:
            xbmcaddon.Addon().setSetting(u'%s' % button_event, u'')
        elif kodi_actions[selected] == custom:
            response = xbmcgui.Dialog().input(u'Custom Kodi Function eingeben')
            if response == u'':
                return
            xbmcaddon.Addon().setSetting(u'%s' % button_event, response)
        elif kodi_actions[selected] == favmusicpath:
            response = xbmcgui.Dialog().browseSingle(0, favmusicpath, u'', u'', False, False, u'')
            if response == u'':
                return
            xbmcaddon.Addon().setSetting(u'%s' % button_event, u'ActivateWindow(Music,%s)' % response)
        elif kodi_actions[selected] == favvideopath:
            response = xbmcgui.Dialog().browseSingle(0, favvideopath, u'', u'', False, False, u'')
            if response == u'':
                return
            xbmcaddon.Addon().setSetting(u'%s' % button_event, u'ActivateWindow(Video,%s)' % response)
        else:
            xbmcaddon.Addon().setSetting(u'%s' % button_event, kodi_actions[selected])
    xbmc.sleep(1000)


def pdc_bg():
    xbmc.executebuiltin(u'Skin.SetImage(IBUS_PDC_BG_IMG,special://skin/media/bmw/pdc/bgs)')
    return
    import xbmcgui
    log(u'PDC: Set Model Type')
    default = xbmcaddon.Addon().getSetting(u'pdc_bg')
    selected = xbmcgui.Dialog().browse(2, u'Choose Kodi Function', u'files', u'.png', True, False, default)
    if selected != default:
        xbmcaddon.Addon().setSetting(u'pdc_bg', selected)
        xbmcgui.Window(10000).setproperty(u'pdc_bg', os.path.splitext(os.path.basename(selected))[0])
    xbmc.sleep(1000)


def set_serialport():
    import xbmcgui
    from serial.tools import list_ports
    log(u'#'.join(list_ports.main()))


def test():
    import xbmcgui
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    current_control = win.getControl(win.getFocusId())


def music_tag():
    log(u'MUSIC TAG START')
    vObject = xbmc.Player().getVideoInfoTag()
    log(dir(vObject))
    log(u'MUSIC TAG ENDE')


def is_osmc():
    if u'osmc' in os.popen(u'uname -n').read().lower():
        return True
    else:
        return False


def is_libreelec():
    if u'libreelec' in os.popen(u'uname -n').read().lower():
        return True
    else:
        return False


def is_windows():
    if u'windows' in platform.system().lower():
        return True
    else:
        return False


def is_rasp_2():
    if u'raspberry pi 2' in os.popen(u'dmesg | grep "Raspberry.Pi.2"').read().lower():
        return True
    else:
        return False


def is_rasp_3():
    if u'raspberry pi 3' in os.popen(u'dmesg | grep "Raspberry.Pi.3"').read().lower():
        return True
    else:
        return False


def set_platform():
    global PLATFORM_HOME_DIR
    global PLATFORM_WINDOWS
    global PLATFORM_SUDO
    global PLATFORM_CONFIG_DIR
    global PIBUS_LOGFILE_PATH
    global PLATFORM_LIBREELEC
    global PIBUS_LOGFILE
    global PLATFORM_OSMC
    global PLATFORM_KODI_LOGFILE
    global PLATFORM_EXPORT_LOGFILE_PATH
    if is_osmc():
        PLATFORM_OSMC = True
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, u'boot')
        PLATFORM_HOME_DIR = os.path.join(os.path.sep, u'home', u'osmc')
        PLATFORM_SUDO = u'sudo '
        PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, u'root')
        PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, u'ibus.txt')
        PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(PLATFORM_CONFIG_DIR, u'ibuscommunicator')
    elif is_libreelec():
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = True
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, u'storage')
        PLATFORM_HOME_DIR = os.path.join(os.path.sep, u'storage')
        PLATFORM_SUDO = u''
        PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, u'storage')
        PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, u'ibus.txt')
        PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(PLATFORM_CONFIG_DIR, u'ibuscommunicator')
    elif is_windows():
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = True
        PLATFORM_CONFIG_DIR = ADDON_USER_PATH
        PLATFORM_HOME_DIR = ADDON_USER_PATH
        PLATFORM_SUDO = u''
        PIBUS_LOGFILE_PATH = ADDON_USER_PATH
        PIBUS_LOGFILE = os.path.join(ADDON_USER_PATH, u'ibus.txt')
        PLATFORM_EXPORT_LOGFILE_PATH = ADDON_USER_PATH
    else:
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = ADDON_USER_PATH
        PLATFORM_HOME_DIR = ADDON_USER_PATH
        PLATFORM_SUDO = u''
        PIBUS_LOGFILE_PATH = ADDON_USER_PATH
        PIBUS_LOGFILE = os.path.join(ADDON_USER_PATH, u'ibus.txt')
        PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(PLATFORM_CONFIG_DIR, u'ibuscommunicator')
    PLATFORM_KODI_LOGFILE = os.path.join(xbmc_translate_path(u'special://logpath'), u'kodi.log')
    PLATFORM_KODI_OLDLOGFILE = os.path.join(xbmc_translate_path(u'special://logpath'), u'kodi.old.log')
    log(u'STARTUP: PLATFORM_OSMC: [%s]' % PLATFORM_OSMC)
    log(u'STARTUP: PLATFORM_LIBREELEC: [%s]' % PLATFORM_LIBREELEC)
    log(u'STARTUP: PLATFORM_WINDOWS: [%s]' % PLATFORM_WINDOWS)
    log(u'STARTUP: PLATFORM_CONFIG_DIR: [%s]' % PLATFORM_CONFIG_DIR)
    log(u'STARTUP: PLATFORM_HOME_DIR: [%s]' % PLATFORM_HOME_DIR)
    log(u'STARTUP: PLATFORM_SUDO: [%s]' % PLATFORM_SUDO)
    log(u'STARTUP: PLATFORM_KODI_LOGFILE: [%s]' % PLATFORM_KODI_LOGFILE)
    log(u'STARTUP: PLATFORM_EXPORT_LOGFILE_PATH: [%s]' % PLATFORM_EXPORT_LOGFILE_PATH)


def call(command):
    log(u'CONSOLE CMD: [%s%s]' % (PLATFORM_SUDO, command), 3)
    return os.popen(u'%s%s' % (PLATFORM_SUDO, command)).read()


def str_to_ustr(s):
    if not PY2 and isinstance(s, str):
        s = u'%s' % s
    return s


def str_to_bstr(s):
    if not PY2 and isinstance(s, str):
        s = bytearray(s, u'utf-8')
    return s


def main():
    set_platform()
    count = len(sys.argv) - 1
    if count > 0:
        log(sys.argv[1])
        given_args = sys.argv[1].split(u';')
        if str(given_args[0]) == u'obc':
            open_obcgui()
        elif str(given_args[0]) == u'text_to_ike':
            try:
                text_to_ike(given_args[1], given_args[2])
            except IndexError:
                text_to_ike(given_args[1])

        elif str(given_args[0]) == u'set_time':
            set_time()
        elif str(given_args[0]) == u'set_date':
            set_date()
        elif str(given_args[0]) == u'get_lcm_oiltemp':
            get_lcm_oiltemp()
        elif str(given_args[0]) == u'mirrors_fold':
            mirrors_fold()
        elif str(given_args[0]) == u'mirrors_unfold':
            mirrors_unfold()
        elif str(given_args[0]) == u'stg_coding':
            stg_coding()
        elif str(given_args[0]) == u'toggle_drl_light':
            toggle_drl_light()
        elif str(given_args[0]) == u'settings':
            open_settings()
        elif str(given_args[0]) == u'update-beta':
            update(u'harryberlin', u'plugin.script.ibuscommunicator')
        elif str(given_args[0]) == u'connect_ibus':
            connect_ibus()
        elif str(given_args[0]) == u'disconnect_ibus':
            disconnect_ibus()
        elif str(given_args[0]) == u'test':
            test()
        elif str(given_args[0]) == u'copy_logfile':
            copy_log_file(True)
        elif str(given_args[0]) == u'pdc_bg':
            pdc_bg()
        elif str(given_args[0]) == u'setup':
            copy_extra_addon_files()
        elif str(given_args[0]) == u'music_tag':
            music_tag()
        elif str(given_args[0]) == u'disconnect_ibus':
            try:
                pass
            except:
                pass

        elif str(given_args[0])[:7] == u'bm_btn_':
            bm_set_button_event(given_args[0])
        else:
            note(u'Unknown Arguments given!', u'%s' % given_args)
    else:
        open_settings()


if __name__ == u'__main__':
    main()
