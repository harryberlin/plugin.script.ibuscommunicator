#!/usr/bin/env python
# -*- coding: utf-8 -*-

__author__ = 'harryberlin'
import os
import sys
import platform
import json
import urllib, urllib2
import zipfile
from resources.lib.kodi_actions import KODI_ACTIONS
import xbmc, xbmcaddon, xbmcvfs, xbmcgui
ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_PATH = ADDON.getAddonInfo('path')
ADDON_USER_PATH = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID)
ADDON_PDC_BG_PATH = os.path.join(ADDON_PATH, 'resources', 'skins', 'Default', 'media', 'pdc', 'bgs', 'default.png')
ICON = os.path.join(ADDON_PATH, 'icon.png')
PLATFORM = platform.system()
PLATFORM_OSMC = True
PLATFORM_LIBREELEC = False
PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, 'boot')
PLATFORM_HOME_DIR = os.path.join(os.path.sep, 'home', 'osmc')
PLATFORM_SUDO = 'sudo '
PLATFORM_KODI_LOGFILE = os.path.join(os.path.sep, 'home', 'osmc', '.kodi', 'temp', 'kodi.log')
PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(os.path.sep, 'boot', 'ibuscommunicator')
ADDON_INFO_LOGFILE = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', 'info.log')
ADDON_IBUS_LOGFILE = os.path.join(xbmc.translatePath('special://userdata'), 'addon_data', ADDON_ID, 'logfiles', 'data.log')
PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, 'root')
PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, 'ibus.txt')
ACTION_PARENT_DIR = 9
ACTION_PREVIOUS_MENU = 10
ACTION_CLOSE_DIALOG = 51
ACTION_SELECT_ITEM = 7
ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_NAV_BACK = 92
ACTION_BACKSPACE = 110

def log(string, lvl = 0):
    return xbmc.log('IBUSCOMMUNICATOR: %s' % string, xbmc.LOGNOTICE)


def note(heading, message = None, time = 5000):
    import xbmcgui
    xbmcgui.Dialog().notification(heading='%s' % heading, message='%s' % message if message else '', icon=ICON, time=time)
    log('NOTIFICATION: "%s%s"' % (heading, ' - %s' % message if message else ''))


def dialog_ok(label1, label2 = '', label3 = ''):
    import xbmcgui
    return xbmcgui.Dialog().ok('IBusCommunicator', label1, label2, label3)


def get_addon_setting(id):
    setting = ADDON.getSetting(id)
    if setting.upper() == 'TRUE':
        return True
    if setting.upper() == 'FALSE':
        return False
    return '%s' % setting


def set_addon_setting(id, value):
    if type(value) == 'bool':
        ADDON.setSetting(id, 'true' if value else 'false')
    else:
        ADDON.setSetting(id, '%s' % value)


def get_property(property, id = 10000):
    import xbmcgui
    return xbmcgui.Window(id).getProperty(property)


def set_property(property, value, id = 10000):
    import xbmcgui
    xbmcgui.Window(id).setProperty(property, value)


def _pbhook(numblocks, blocksize, filesize, url = None, dp = None):
    if dp.iscanceled():
        print 'Download Abgebrochen'
        raise Exception('dialog canceled')
    try:
        percent = min(numblocks * blocksize * 100 / filesize, 100)
        current_size = '%.*f' % (2, numblocks * blocksize / 1024.0 / 1024.0)
        total_size = '%.*f' % (2, filesize / 1024.0 / 1024.0)
        print percent
        teststr = '%s / %s MB / %s%%' % (current_size, total_size, percent)
        dp.update(int(10 + percent * 0.4), 'Downloading...', teststr, '%s%%' % int(10 + percent * 0.4))
    except:
        pass


def is_internet_available():
    try:
        urllib2.urlopen('http://216.58.192.142', timeout=1)
        return True
    except:
        return False


def copy_log_fileOLD(show_dialog = False):
    global PLATFORM_KODI_LOGFILE
    global PIBUS_LOGFILE
    global PLATFORM_EXPORT_LOGFILE_PATH
    import zipfile
    from datetime import datetime
    log('LOGFILE: COPY LOG FILE TO "/boot/ibuscommunicator"')
    if not os.path.exists(PLATFORM_EXPORT_LOGFILE_PATH):
        os.popen('sudo -s mkdir %s' % PLATFORM_EXPORT_LOGFILE_PATH)
    log('LOGFILE: Create Zip File')
    filename = datetime.now().strftime('%Y%m%d_%H%M%S_ibuscommunicator.zip')
    dest_logfile = os.path.join(PLATFORM_EXPORT_LOGFILE_PATH, filename)
    zip = zipfile.ZipFile(os.path.join(ADDON_USER_PATH, filename), 'w', zipfile.ZIP_DEFLATED)
    zip.write(PLATFORM_KODI_LOGFILE, os.path.split(PLATFORM_KODI_LOGFILE)[1])
    if not get_addon_setting('log_to_kodi'):
        zip.write(ADDON_INFO_LOGFILE, os.path.split(ADDON_INFO_LOGFILE)[1])
        zip.write(ADDON_IBUS_LOGFILE, os.path.split(ADDON_IBUS_LOGFILE)[1])
    if get_addon_setting('pibus'):
        os.popen('sudo chown -R osmc:osmc "%s"' % os.path.join('root'))
        os.popen('sudo chown -R osmc:osmc "%s"' % PIBUS_LOGFILE)
        zip.write(PIBUS_LOGFILE, os.path.split(PIBUS_LOGFILE)[1])
    zip.close()
    log('LOGFILE: Move Zip File')
    os.popen('sudo -s mv %s %s' % (os.path.join(ADDON_USER_PATH, filename), dest_logfile))
    if show_dialog:
        dialog_ok('LOGFILE: <%s>' % filename, 'created on:', PLATFORM_EXPORT_LOGFILE_PATH)


def copy_log_file(show_dialog = False):
    global PIBUS_LOGFILE_PATH
    import zipfile
    from datetime import datetime
    if not xbmcvfs.exists(PLATFORM_EXPORT_LOGFILE_PATH):
        call('mkdir %s' % PLATFORM_EXPORT_LOGFILE_PATH)
    log('LOGFILE: COPY LOG FILE TO "%s"' % PLATFORM_EXPORT_LOGFILE_PATH)
    if not xbmcvfs.exists(PLATFORM_EXPORT_LOGFILE_PATH):
        call('mkdir %s' % PLATFORM_EXPORT_LOGFILE_PATH)
    log('LOGFILE: Create Zip File')
    filename = datetime.now().strftime('%Y%m%d_%H%M%S_ibuscommunicator.zip')
    dest_logfile = os.path.join(PLATFORM_EXPORT_LOGFILE_PATH, filename)
    zip = zipfile.ZipFile(os.path.join(ADDON_USER_PATH, filename), 'w', zipfile.ZIP_DEFLATED)
    try:
        zip.write(PLATFORM_KODI_LOGFILE, os.path.split(PLATFORM_KODI_LOGFILE)[1])
        if not get_addon_setting('log_to_kodi'):
            zip.write(ADDON_INFO_LOGFILE, os.path.split(ADDON_INFO_LOGFILE)[1])
            zip.write(ADDON_IBUS_LOGFILE, os.path.split(ADDON_IBUS_LOGFILE)[1])
        if get_addon_setting('pibus'):
            if is_osmc():
                call('chown -R osmc:osmc "%s"' % PIBUS_LOGFILE_PATH)
                call('chown -R osmc:osmc "%s"' % PIBUS_LOGFILE)
            else:
                call('chown -R root:root "%s"' % PIBUS_LOGFILE_PATH)
                call('chown -R root:root "%s"' % PIBUS_LOGFILE)
            zip.write(PIBUS_LOGFILE, os.path.split(PIBUS_LOGFILE)[1])
        zip.close()
    except ValueError:
        log('LOGFILE: Can not create Zip File')
        zip.close()
        return

    log('LOGFILE: Move Zip File')
    call('mv %s %s' % (os.path.join(ADDON_USER_PATH, filename), dest_logfile))
    if show_dialog:
        dialog_ok('LOGFILE: <%s>' % filename, 'created on:', PLATFORM_EXPORT_LOGFILE_PATH)


def copy_extra_addon_files():
    import xbmcgui
    if not xbmcgui.Dialog().yesno('IBusCommunicator', 'Are your sure to copy / replace skin files?', '', '[COLOR FFFF0000]NO BACKUP FUNCTION INCLUDED[/COLOR]'):
        return
    if xbmc.getSkinDir() != 'skin.confluence-vertical':
        dialog_ok('Current skin in not "skin.confluence-vertical"')
        return
    addon_path = os.path.join(ADDON_PATH, 'resources', 'replace_skin_files', '*.*')
    skin_path = os.path.join(xbmcaddon.Addon(xbmc.getSkinDir()).getAddonInfo('path'), '720p')
    os.popen('sudo -s cp %s %s' % (addon_path, skin_path))
    if not xbmcgui.Dialog().yesno('IBusCommunicator', 'Extra addon skin files were', 'copied / replaced.', yeslabel='Restart Kodi', nolabel='Reload Skin'):
        xbmc.executebuiltin('ReloadSkin()')
    else:
        os.popen('sudo systemctl restart mediacenter')


def _send_command(message):
    import time
    import socket
    clientsocket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    clientsocket.settimeout(0.1)
    port = int(get_addon_setting('tcp_port'))
    try:
        clientsocket.connect(('localhost', port))
    except:
        return False

    log('# TCP %s: SEND >%s<' % (port, message.upper()))
    clientsocket.send(message)
    time.sleep(0.2)
    answer = clientsocket.recv(50).replace('\n', '')
    time.sleep(0.2)
    clientsocket.shutdown(True)
    if answer == 'OK':
        return True
    else:
        return False


def dialog_progressbar_timeout(dp, line_1, line_2, line_3, timeout = 3000):
    for _ in range(100, 0, -1):
        if dp.iscanceled():
            break
        dp.update(_, line_1, line_2, line_3)
        xbmc.sleep(timeout / 100)


def update(owner, repo, branch = 'master'):
    dp = xbmcgui.DialogProgress()
    dp.create('Updating %s-Beta' % ADDON_NAME, ' ')
    dp.update(1, 'Check Connection...', ' ', '1%')
    try:
        if not is_internet_available():
            raise Exception('No Internet connection')
        dp.update(5, 'Check for new Version on github...', ' ', '5%')
        try:
            url = 'https://api.github.com/repos/%s/%s/git/refs/heads/%s' % (owner, repo, branch)
            res = json.loads(urllib2.urlopen(url).read())
            log(res)
            sha_url = res['object']['url']
            res = json.loads(urllib2.urlopen(sha_url).read())
            commit_date = res['committer']['date']
            sha = res['sha']
        except:
            raise Exception('Try again later')

        print sha
        if ADDON.getSettingString('github_sha') == sha:
            raise Exception('No Update required')
        print 'downloading file'
        dp.update(10, 'Downloading...', ' ', '10%')
        url = 'https://github.com/harryberlin/plugin.script.ibuscommunicator/raw/master/plugin.script.ibuscommunicator-beta.zip'
        target_path = os.path.join(ADDON_USER_PATH, 'plugin.script.ibuscommunicator-beta.zip')
        urllib.urlretrieve(url, target_path, lambda nb, bs, fs, url = url: _pbhook(nb, bs, fs, url, dp))
        dp.update(50, 'Check Zipfile...', ' ', '50%')
        the_zip_file = zipfile.ZipFile(target_path, 'r')
        ret = the_zip_file.testzip()
        if ret is not None:
            raise Exception('Zipfile is bad')
        dp.update(50, 'Checked Zipfile', ' ', '50%')
        zip_count = 0
        zip_max_count = len(the_zip_file.infolist())
        for zipinfo in the_zip_file.infolist():
            zip_count += 1
            if zipinfo.filename.startswith('plugin.script.ibuscommunicator'):
                zipinfo.filename = zipinfo.filename.replace('plugin.script.ibuscommunicator', '')
                dp.update(int(50 + int(float(zip_count) / float(zip_max_count) * 100) * 0.5), 'Extracting Files...', '%s / %s / %s%%' % (zip_count, zip_max_count, int(float(zip_count) / float(zip_max_count) * 100)), '%s%%' % int(50 + int(float(zip_count) / float(zip_max_count) * 100) * 0.5))
                try:
                    import resources.lib.test
                    the_zip_file.extract(zipinfo, os.path.join(ADDON_PATH, 'test'))
                except ImportError:
                    the_zip_file.extract(zipinfo, ADDON_PATH)

        the_zip_file.close()
        set_addon_setting('github_sha', '%s' % sha)
        xbmc.sleep(400)
        commit_str_date = '%s' % commit_date.replace('T', ' ').replace('Z', ' ')
        dialog_progressbar_timeout(dp, 'Update finished', 'Release: %s' % commit_str_date, ' ', 3000)
        xbmc.executebuiltin('XBMC.UpdateLocalAddons()')
    except Exception as e:
        dialog_progressbar_timeout(dp, e.message, ' ', ' ', 7000)
    finally:
        dp.close()


def open_obcgui():
    if not _send_command('obc;opengui'):
        note('Error by opening OBC GUI')


def text_to_ike(text, gong = 'False'):
    if not _send_command('text_to_ike;%s;%s' % (text, gong)):
        note('Error by sending TEXT TO IKE')


def set_time():
    if not _send_command('set_time'):
        note('Error by setting IKE Time')


def set_date():
    if not _send_command('set_date'):
        note('Error by setting IKE Date')


def get_lcm_oiltemp():
    if not _send_command('get_lcm_oiltemp'):
        note('Error by getting LCM Oiltemp')


def mirrors_fold():
    if not _send_command('mirrors_fold'):
        note('Error by folding Mirrors')


def mirrors_unfold():
    if not _send_command('mirrors_unfold'):
        note('Error by unfolding Mirrors')


def toggle_drl_light():
    if get_addon_setting('drl_light'):
        set_addon_setting('drl_light', False)
    else:
        set_addon_setting('drl_light', True)


def stg_coding():

    def code_us_sidemark():
        if not _send_command('code_us_sidemark'):
            note('Error by Request LCM Coding Data')

    def code_pwm_park():
        if not _send_command('code_pwm_park'):
            note('Error by Request LCM Coding Data')

    import xbmcgui
    if not xbmcgui.Dialog().yesno('CODING FUNCTIONS', 'Use this Function at your own risk!', "Don't continue, if you're unsure", 'You know what you do? Are you sure?', 'Cancel', "I'm sure"):
        return
    codings = ['LCM-Coding: US SIDEMARK', 'LCM-Coding: (LCM.C20=>) PWM PARK LIGHTS FRONT']
    ret = xbmcgui.Dialog().select('CODING FUNCTIONS', codings)
    if ret == 0:
        code_us_sidemark()
    elif ret == 1:
        code_pwm_park()


def open_settings():
    import xbmcgui
    if xbmcgui.getCurrentWindowDialogId() == 10140:
        xbmc.executeJSONRPC('{ "jsonrpc": "2.0", "method": "Input.Back", "id": 1 }')
    else:
        xbmcaddon.Addon().openSettings()


def connect_ibus():
    pass


def disconnect_ibus():
    pass


def bm_set_button_event(button_nbr):
    import xbmcgui
    log('Set Event for BM Button: %s' % button_nbr)
    favmusicpath = 'Favorite Music Path'
    custom = '-- CUSTOM --'
    reset = '---- RESET ---'
    kodi_actions = sorted(KODI_ACTIONS.keys())
    kodi_actions.extend([favmusicpath, custom, reset])
    selected = xbmcgui.Dialog().select('Choose Kodi Function', kodi_actions)
    if selected != -1:
        if kodi_actions[selected] == reset:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, '')
        elif kodi_actions[selected] == custom:
            response = xbmcgui.Dialog().input('Custom Kodi Function eingeben')
            if response == '':
                return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, response)
        elif kodi_actions[selected] == favmusicpath:
            response = xbmcgui.Dialog().browseSingle(0, favmusicpath, 'files', '', False, False, '')
            if response == '':
                return
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, 'ActivateWindow(Music,%s)' % response)
        else:
            xbmcaddon.Addon().setSetting('bm_btn_%s' % button_nbr, kodi_actions[selected])
    xbmc.sleep(1000)


def pdc_bg():
    xbmc.executebuiltin('Skin.SetImage(IBUS_PDC_BG_IMG,special://skin/media/bmw/pdc/bgs)')
    return
    import xbmcgui
    log('PDC: Set Model Type')
    default = xbmcaddon.Addon().getSetting('pdc_bg')
    selected = xbmcgui.Dialog().browse(2, 'Choose Kodi Function', 'files', '.png', True, False, default)
    if selected != default:
        xbmcaddon.Addon().setSetting('pdc_bg', selected)
        xbmcgui.Window(10000).setProperty('pdc_bg', os.path.splitext(os.path.basename(selected))[0])
    xbmc.sleep(1000)


def set_serialport():
    import xbmcgui
    from serial.tools import list_ports
    log('#'.join(list_ports.main()))


def test():
    import xbmcgui
    win = xbmcgui.Window(xbmcgui.getCurrentWindowId())
    current_control = win.getControl(win.getFocusId())


def music_tag():
    log('MUSIC TAG START')
    vObject = xbmc.Player().getVideoInfoTag()
    log(dir(vObject))
    log('MUSIC TAG ENDE')


def is_osmc():
    if 'osmc' in os.popen('uname -n').read().lower():
        return True
    else:
        return False


def is_libreelec():
    if 'libreelec' in os.popen('uname -n').read().lower():
        return True
    else:
        return False


def is_windows():
    if 'windows' in platform.system().lower():
        return True
    else:
        return False


def is_rasp_2():
    if 'raspberry pi 2' in os.popen('dmesg | grep "Raspberry.Pi.2"').read().lower():
        return True
    else:
        return False


def is_rasp_3():
    if 'raspberry pi 3' in os.popen('dmesg | grep "Raspberry.Pi.3"').read().lower():
        return True
    else:
        return False


def set_platform():
    global PLATFORM_HOME_DIR
    global PLATFORM_SUDO
    global PLATFORM_CONFIG_DIR
    global PIBUS_LOGFILE_PATH
    global PLATFORM_LIBREELEC
    global PIBUS_LOGFILE
    global PLATFORM_OSMC
    global PLATFORM_KODI_LOGFILE
    global PLATFORM_EXPORT_LOGFILE_PATH
    if is_osmc():
        PLATFORM_OSMC = True
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, 'boot')
        PLATFORM_HOME_DIR = os.path.join(os.path.sep, 'home', 'osmc')
        PLATFORM_SUDO = 'sudo '
        PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, 'root')
        PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, 'ibus.txt')
    elif is_libreelec():
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = True
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = os.path.join(os.path.sep, 'storage')
        PLATFORM_HOME_DIR = os.path.join(os.path.sep, 'storage')
        PLATFORM_SUDO = ''
        PIBUS_LOGFILE_PATH = os.path.join(os.path.sep, 'storage')
        PIBUS_LOGFILE = os.path.join(PIBUS_LOGFILE_PATH, 'ibus.txt')
    elif is_windows():
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = True
        PLATFORM_CONFIG_DIR = ADDON_USER_PATH
        PLATFORM_HOME_DIR = ADDON_USER_PATH
        PLATFORM_SUDO = ''
        PIBUS_LOGFILE_PATH = ADDON_USER_PATH
        PIBUS_LOGFILE = os.path.join(ADDON_USER_PATH, 'ibus.txt')
    else:
        PLATFORM_OSMC = False
        PLATFORM_LIBREELEC = False
        PLATFORM_WINDOWS = False
        PLATFORM_CONFIG_DIR = ADDON_USER_PATH
        PLATFORM_HOME_DIR = ADDON_USER_PATH
        PLATFORM_SUDO = ''
        PIBUS_LOGFILE_PATH = ADDON_USER_PATH
        PIBUS_LOGFILE = os.path.join(ADDON_USER_PATH, 'ibus.txt')
    PLATFORM_KODI_LOGFILE = os.path.join(PLATFORM_HOME_DIR, '.kodi', 'temp', 'kodi.log')
    PLATFORM_EXPORT_LOGFILE_PATH = os.path.join(PLATFORM_CONFIG_DIR, 'ibuscommunicator')
    log('STARTUP: PLATFORM_OSMC: [%s]' % PLATFORM_OSMC)
    log('STARTUP: PLATFORM_LIBREELEC: [%s]' % PLATFORM_LIBREELEC)
    log('STARTUP: PLATFORM_CONFIG_DIR: [%s]' % PLATFORM_CONFIG_DIR)
    log('STARTUP: PLATFORM_HOME_DIR: [%s]' % PLATFORM_HOME_DIR)
    log('STARTUP: PLATFORM_SUDO: [%s]' % PLATFORM_SUDO)
    log('STARTUP: PLATFORM_KODI_LOGFILE: [%s]' % PLATFORM_KODI_LOGFILE)
    log('STARTUP: PLATFORM_EXPORT_LOGFILE_PATH: [%s]' % PLATFORM_EXPORT_LOGFILE_PATH)


def call(command):
    log('CONSOLE CMD: [%s%s]' % (PLATFORM_SUDO, command), 3)
    return os.popen('%s%s' % (PLATFORM_SUDO, command)).read()


def main():
    set_platform()
    count = len(sys.argv) - 1
    if count > 0:
        given_args = sys.argv[1].split(';')
        if str(given_args[0]) == 'obc':
            open_obcgui()
        elif str(given_args[0]) == 'text_to_ike':
            try:
                text_to_ike(given_args[1], given_args[2])
            except IndexError:
                text_to_ike(given_args[1])

        elif str(given_args[0]) == 'set_time':
            set_time()
        elif str(given_args[0]) == 'set_date':
            set_date()
        elif str(given_args[0]) == 'get_lcm_oiltemp':
            get_lcm_oiltemp()
        elif str(given_args[0]) == 'mirrors_fold':
            mirrors_fold()
        elif str(given_args[0]) == 'mirrors_unfold':
            mirrors_unfold()
        elif str(given_args[0]) == 'stg_coding':
            stg_coding()
        elif str(given_args[0]) == 'toggle_drl_light':
            toggle_drl_light()
        elif str(given_args[0]) == 'settings':
            open_settings()
        elif str(given_args[0]) == 'update-beta':
            update('harryberlin', 'plugin.script.ibuscommunicator')
        elif str(given_args[0]) == 'connect_ibus':
            connect_ibus()
        elif str(given_args[0]) == 'disconnect_ibus':
            disconnect_ibus()
        elif str(given_args[0]) == 'test':
            test()
        elif str(given_args[0]) == 'copy_logfile':
            copy_log_file(True)
        elif str(given_args[0]) == 'pdc_bg':
            pdc_bg()
        elif str(given_args[0]) == 'setup':
            copy_extra_addon_files()
        elif str(given_args[0]) == 'music_tag':
            music_tag()
        elif str(given_args[0]) == 'disconnect_ibus':
            try:
                pass
            except:
                pass

        elif str(given_args[0]) == 'bm_btn':
            bm_set_button_event(given_args[1])
        else:
            note('Unknown Arguments given!', '%s' % given_args)
    else:
        open_settings()


if __name__ == '__main__':
    main()
