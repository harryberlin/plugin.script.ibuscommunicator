# -*- coding: utf-8 -*-

__author__ = 'harryberlin'

from resources.lib import default

if __name__ == '__main__':
    default.main()
